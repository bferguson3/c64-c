This directory contains exomizer decrunchers in assembly for Intel 8088/86 contributed by Ivan Gorodetsky (retrocomp@yandex.ru).
Compile with flat assembler (FASM)
